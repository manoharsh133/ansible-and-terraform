#!/bin/bash
echo "This is chatbox application"

# Adding new feature
if a == "hi"
{ 
echo "How can I help you ?"
{
else
echo "Please provide valid input"
}
}

#!/bin/bash
echo "This is chatbox application"

# Adding new feature
echo "emoji based on conversation"
